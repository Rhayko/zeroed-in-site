"""Reproduce an explicitly synthetic commerce margin case. Standard library only."""
import csv,json,random,sqlite3,hashlib
from pathlib import Path
from datetime import date,timedelta
ROOT=Path(__file__).resolve().parent
def build(destination):
    destination=Path(destination)
    if destination.exists():raise ValueError('Choose a new output directory; existing runs are preserved.')
    destination.mkdir(parents=True)
    db=sqlite3.connect(destination/'commerce.sqlite');db.executescript((ROOT/'model.sql').read_text())
    rng=random.Random(3192026)
    channels=[('DIRECT','Direct'),('SEARCH','Paid search'),('SOCIAL','Paid social'),('PARTNER','Partner')]
    db.executemany('INSERT INTO channels VALUES(?,?)',channels)
    products=[('P01','Trail pack','Equipment',8900,4300),('P02','Travel duffel','Equipment',7400,3800),('P03','Utility tote','Equipment',4200,2300),('P04','Training tee','Apparel',3200,1500),('P05','Training shorts','Apparel',4500,2400),('P06','Rain shell','Apparel',11900,6700),('P07','Insulated bottle','Accessories',2800,1300),('P08','Packing cubes','Accessories',2400,1000),('P09','Wool socks','Accessories',1800,800)]
    db.executemany('INSERT INTO products VALUES(?,?,?)',[p[:3] for p in products])
    line_no=0;return_no=0
    for n in range(1,2401):
        day=date(2025,7,1)+timedelta(days=rng.randrange(184))
        channel=rng.choices([c[0] for c in channels],[26,29,33,12])[0]
        oid=f'O{n:05}';fulfill=rng.randrange(650,1101)+(250 if channel=='PARTNER' else 0)
        db.execute('INSERT INTO orders VALUES(?,?,?,?)',(oid,day.isoformat(),channel,fulfill))
        for p in rng.sample(products,rng.choices([1,2,3],[45,40,15])[0]):
            line_no+=1;lid=f'L{line_no:06}';qty=rng.choices([1,2,3],[70,23,7])[0]
            pct=rng.choice([15,20,25]) if channel=='SOCIAL' else rng.choice([0,5,10])
            discount=qty*p[3]*pct//100
            db.execute('INSERT INTO order_lines VALUES(?,?,?,?,?,?,?)',(lid,oid,p[0],qty,p[3],p[4],discount))
            probability=(.24 if channel=='SOCIAL' else .07)+(.10 if p[2]=='Apparel' else 0)
            returned=sum(rng.random()<probability for _ in range(qty))
            # One event per unit deliberately permits multiple return events per line.
            for _ in range(returned):
                return_no+=1;refund=p[3]*(100-pct)//100
                recovered=p[4] if rng.random()<.72 else 0
                db.execute('INSERT INTO returns VALUES(?,?,?,?,?,?,?)',(f'R{return_no:05}',lid,(day+timedelta(days=rng.randrange(1,31))).isoformat(),1,refund,recovered,350))
    for month in range(7,13):
        for channel,spend in [('DIRECT',0),('SEARCH',250000),('SOCIAL',380000),('PARTNER',65000)]:
            db.execute('INSERT INTO channel_spend VALUES(?,?,?)',(f'2025-{month:02}',channel,spend))
    db.commit();db.row_factory=sqlite3.Row
    for table in ['channels','products','orders','order_lines','returns','channel_spend','line_economics','order_economics','channel_month_economics']:
        cur=db.execute('SELECT * FROM '+table);rows=cur.fetchall()
        with (destination/(table+'.csv')).open('w',newline='') as f:
            w=csv.writer(f);w.writerow([c[0] for c in cur.description]);w.writerows(rows)
    summary=[dict(r) for r in db.execute('SELECT * FROM channel_month_economics ORDER BY month,channel_id')]
    (destination/'dashboard.json').write_text(json.dumps(summary,indent=2)+'\n')
    manifest={'seed':3192026,'snapshot':'2026-02-01','currency':'USD','money_storage':'integer cents','tables':{t:db.execute('SELECT COUNT(*) FROM '+t).fetchone()[0] for t in ['channels','products','orders','order_lines','returns','channel_spend']},'csv_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(destination.glob('*.csv'))}}
    (destination/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');db.close()
    print(json.dumps(manifest['tables']))
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();build(a.output)
