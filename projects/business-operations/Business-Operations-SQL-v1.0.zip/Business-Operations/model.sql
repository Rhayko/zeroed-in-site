PRAGMA foreign_keys=ON;
CREATE TABLE channels(channel_id TEXT PRIMARY KEY, channel_name TEXT NOT NULL);
CREATE TABLE products(product_id TEXT PRIMARY KEY, product_name TEXT NOT NULL, category TEXT NOT NULL);
CREATE TABLE orders(order_id TEXT PRIMARY KEY, order_date TEXT NOT NULL, channel_id TEXT NOT NULL REFERENCES channels(channel_id), fulfillment_cents INTEGER NOT NULL CHECK(fulfillment_cents>=0));
CREATE TABLE order_lines(line_id TEXT PRIMARY KEY, order_id TEXT NOT NULL REFERENCES orders(order_id), product_id TEXT NOT NULL REFERENCES products(product_id), quantity INTEGER NOT NULL CHECK(quantity>0), unit_price_cents INTEGER NOT NULL CHECK(unit_price_cents>0), unit_cost_cents INTEGER NOT NULL CHECK(unit_cost_cents>=0), discount_cents INTEGER NOT NULL CHECK(discount_cents>=0 AND discount_cents<=quantity*unit_price_cents));
CREATE TABLE returns(return_id TEXT PRIMARY KEY, line_id TEXT NOT NULL REFERENCES order_lines(line_id), return_date TEXT NOT NULL, quantity INTEGER NOT NULL CHECK(quantity>0), refund_cents INTEGER NOT NULL CHECK(refund_cents>=0), recovered_cost_cents INTEGER NOT NULL CHECK(recovered_cost_cents>=0), processing_cents INTEGER NOT NULL CHECK(processing_cents>=0));
CREATE TABLE channel_spend(month TEXT NOT NULL, channel_id TEXT NOT NULL REFERENCES channels(channel_id), spend_cents INTEGER NOT NULL CHECK(spend_cents>=0), PRIMARY KEY(month,channel_id));
CREATE INDEX ix_lines_order ON order_lines(order_id);
CREATE INDEX ix_returns_line ON returns(line_id);
-- First reduce returns to line grain. A direct one-to-many join would repeat sales.
CREATE VIEW line_economics AS
WITH r AS (SELECT line_id,SUM(quantity) returned_units,SUM(refund_cents) refunds,
 SUM(recovered_cost_cents) recovered_cost,SUM(processing_cents) return_processing
 FROM returns GROUP BY line_id)
SELECT l.*,o.order_date,SUBSTR(o.order_date,1,7) month,o.channel_id,
 l.quantity*l.unit_price_cents gross_sales,
 COALESCE(r.returned_units,0) returned_units,COALESCE(r.refunds,0) refunds,
 COALESCE(r.recovered_cost,0) recovered_cost,COALESCE(r.return_processing,0) return_processing,
 l.quantity*l.unit_price_cents-l.discount_cents-COALESCE(r.refunds,0) net_sales,
 l.quantity*l.unit_cost_cents-COALESCE(r.recovered_cost,0) net_product_cost,
 l.quantity*l.unit_price_cents-l.discount_cents-COALESCE(r.refunds,0)
 -(l.quantity*l.unit_cost_cents-COALESCE(r.recovered_cost,0))-COALESCE(r.return_processing,0) product_contribution
FROM order_lines l JOIN orders o USING(order_id) LEFT JOIN r USING(line_id);
-- Reduce lines to order grain before deducting a once-per-order fulfillment cost.
CREATE VIEW order_economics AS
SELECT o.order_id,o.order_date,o.channel_id,SUBSTR(o.order_date,1,7) month,
 SUM(l.gross_sales) gross_sales,SUM(l.discount_cents) discounts,SUM(l.refunds) refunds,
 SUM(l.net_sales) net_sales,SUM(l.net_product_cost) net_product_cost,
 SUM(l.return_processing) return_processing,o.fulfillment_cents,
 SUM(l.quantity) units,SUM(l.returned_units) returned_units,
 SUM(l.product_contribution)-o.fulfillment_cents contribution_before_marketing
FROM orders o JOIN line_economics l USING(order_id) GROUP BY o.order_id;
-- Channel-month spine preserves spend even if a channel has no orders that month.
CREATE VIEW channel_month_economics AS
WITH sales AS (SELECT month,channel_id,COUNT(*) orders,SUM(gross_sales) gross_sales,
 SUM(discounts) discounts,SUM(refunds) refunds,SUM(net_sales) net_sales,
 SUM(net_product_cost) net_product_cost,SUM(return_processing) return_processing,
 SUM(fulfillment_cents) fulfillment,SUM(units) units,SUM(returned_units) returned_units,
 SUM(contribution_before_marketing) contribution_before_marketing
 FROM order_economics GROUP BY month,channel_id),
spine AS (SELECT month,channel_id FROM sales UNION SELECT month,channel_id FROM channel_spend)
SELECT spine.month,spine.channel_id,c.channel_name,COALESCE(s.orders,0) orders,
 COALESCE(s.gross_sales,0) gross_sales,COALESCE(s.discounts,0) discounts,
 COALESCE(s.refunds,0) refunds,COALESCE(s.net_sales,0) net_sales,
 COALESCE(s.net_product_cost,0) net_product_cost,COALESCE(s.return_processing,0) return_processing,
 COALESCE(s.fulfillment,0) fulfillment,COALESCE(s.units,0) units,COALESCE(s.returned_units,0) returned_units,
 COALESCE(s.contribution_before_marketing,0) contribution_before_marketing,
 COALESCE(m.spend_cents,0) marketing_spend,
 COALESCE(s.contribution_before_marketing,0)-COALESCE(m.spend_cents,0) contribution_after_marketing
FROM spine JOIN channels c USING(channel_id) LEFT JOIN sales s USING(month,channel_id)
LEFT JOIN channel_spend m USING(month,channel_id);
