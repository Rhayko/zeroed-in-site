import unittest,sqlite3,tempfile,csv
from pathlib import Path
from datetime import date
from build import build,ROOT
class ModelTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tmp=tempfile.TemporaryDirectory();cls.out=Path(cls.tmp.name)/'run';build(cls.out)
  cls.db=sqlite3.connect(cls.out/'commerce.sqlite');cls.db.row_factory=sqlite3.Row
 @classmethod
 def tearDownClass(cls):cls.db.close();cls.tmp.cleanup()
 def scalar(self,q):return self.db.execute(q).fetchone()[0]
 def test_foreign_keys(self):self.assertEqual(list(self.db.execute('PRAGMA foreign_key_check')),[])
 def test_database_integrity(self):self.assertEqual(self.scalar('PRAGMA integrity_check'),'ok')
 def test_order_grain(self):self.assertEqual(self.scalar('SELECT COUNT(*) FROM order_economics'),2400)
 def test_line_grain(self):self.assertEqual(self.scalar('SELECT COUNT(*) FROM line_economics'),self.scalar('SELECT COUNT(*) FROM order_lines'))
 def test_fulfillment_not_multiplied(self):self.assertEqual(self.scalar('SELECT SUM(fulfillment) FROM channel_month_economics'),self.scalar('SELECT SUM(fulfillment_cents) FROM orders'))
 def test_marketing_not_multiplied(self):self.assertEqual(self.scalar('SELECT SUM(marketing_spend) FROM channel_month_economics'),self.scalar('SELECT SUM(spend_cents) FROM channel_spend'))
 def test_return_bounds(self):
  self.assertEqual(self.scalar('SELECT COUNT(*) FROM line_economics WHERE returned_units>quantity OR refunds>gross_sales-discount_cents OR recovered_cost>quantity*unit_cost_cents'),0)
 def test_mature_return_window(self):
  for r in self.db.execute('SELECT r.return_date,o.order_date FROM returns r JOIN order_lines l USING(line_id) JOIN orders o USING(order_id)'):
   self.assertTrue(1<=(date.fromisoformat(r[0])-date.fromisoformat(r[1])).days<=30)
   self.assertLess(date.fromisoformat(r[0]),date(2026,2,1))
 def test_independent_total(self):
  # Recompute directly from base tables in Python, without the analytical views.
  lines=list(self.db.execute('SELECT * FROM order_lines'));returns=list(self.db.execute('SELECT * FROM returns'))
  net=sum(r['quantity']*r['unit_price_cents']-r['discount_cents'] for r in lines)-sum(r['refund_cents'] for r in returns)
  cost=sum(r['quantity']*r['unit_cost_cents'] for r in lines)-sum(r['recovered_cost_cents'] for r in returns)
  contribution=net-cost-sum(r['processing_cents'] for r in returns)-self.scalar('SELECT SUM(fulfillment_cents) FROM orders')-self.scalar('SELECT SUM(spend_cents) FROM channel_spend')
  self.assertEqual(net,self.scalar('SELECT SUM(net_sales) FROM channel_month_economics'))
  self.assertEqual(contribution,self.scalar('SELECT SUM(contribution_after_marketing) FROM channel_month_economics'))
 def test_every_channel_month(self):
  for row in self.db.execute('SELECT * FROM channel_month_economics'):
   lines=list(self.db.execute('SELECT l.* FROM order_lines l JOIN orders o USING(order_id) WHERE o.channel_id=? AND substr(o.order_date,1,7)=?',(row['channel_id'],row['month'])))
   ids={l['line_id'] for l in lines};refunds=sum(r['refund_cents'] for r in self.db.execute('SELECT * FROM returns') if r['line_id'] in ids)
   self.assertEqual(row['net_sales'],sum(l['quantity']*l['unit_price_cents']-l['discount_cents'] for l in lines)-refunds)
 def test_multiple_returns_present(self):self.assertGreater(self.scalar('SELECT COUNT(*) FROM (SELECT line_id FROM returns GROUP BY line_id HAVING COUNT(*)>1)'),0)
 def test_queries_execute(self):
  for q in (ROOT/'analysis.sql').read_text().split(';'):
   if q.strip():self.db.execute(q).fetchall()
 def test_reproduction(self):
  second=Path(self.tmp.name)/'repeat';build(second)
  for f in self.out.glob('*.csv'):self.assertEqual(f.read_bytes(),(second/f.name).read_bytes())
 def test_no_overwrite(self):
  with self.assertRaises(ValueError):build(self.out)
 def test_zero_sales_spend_preserved(self):
  db=sqlite3.connect(':memory:');db.executescript((ROOT/'model.sql').read_text())
  db.execute("INSERT INTO channels VALUES('X','Empty')");db.execute("INSERT INTO channel_spend VALUES('2025-07','X',999)")
  self.assertEqual(db.execute('SELECT net_sales,contribution_after_marketing FROM channel_month_economics').fetchone(),(0,-999));db.close()
 def test_known_partial_and_full_returns(self):
  db=sqlite3.connect(':memory:');db.executescript((ROOT/'model.sql').read_text())
  db.executescript("INSERT INTO channels VALUES('X','Example');INSERT INTO products VALUES('P','Product','Category');INSERT INTO orders VALUES('O','2025-07-01','X',500);INSERT INTO order_lines VALUES('L','O','P',2,2000,1000,400);INSERT INTO returns VALUES('R1','L','2025-07-02',1,1800,1000,200);")
  self.assertEqual(db.execute('SELECT net_sales,contribution_before_marketing FROM order_economics').fetchone(),(1800,100))
  db.execute("INSERT INTO returns VALUES('R2','L','2025-07-03',1,1800,0,200)")
  self.assertEqual(db.execute('SELECT net_sales,contribution_before_marketing FROM order_economics').fetchone(),(0,-1900));db.close()
if __name__=='__main__':unittest.main()
