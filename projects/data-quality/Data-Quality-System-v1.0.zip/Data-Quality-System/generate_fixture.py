"""Build a reproducible, deliberately imperfect feed from the synthetic KPI ledger.
The pipeline does not read expected.json; it is an independent test oracle.
"""
import csv,json,random,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def generate():
    with (ROOT/'data/baseline.csv').open(newline='') as f:
        reader=csv.DictReader(f); fields=reader.fieldnames; base=list(reader)
    rows=[dict(r) for r in base]
    repairs={}
    for i in range(40):
        r=rows[i]
        if i%4==0:r['site']=' '+r['site'].lower()+' ';r['shift']=' '+r['shift'].lower()+' '
        if i%4==1:r['date']=r['date'][5:7]+'/'+r['date'][8:]+'/'+r['date'][:4]
        if i%4==2:r['record_id']=' '+r['record_id']+' ';r['orders_due']=r['orders_due']+'.0'
        if i%4==3:r['units_shipped']=f"{int(r['units_shipped']):,}";r['regular_hours']=' '+r['regular_hours']+' '
        repairs[r['record_id'].strip()]=i
    bad={}
    issues=[('orders_due','', 'MISSING_VALUE'),('date','2025-02-30','INVALID_DATE'),('on_time_orders','-1','NEGATIVE_VALUE'),('regular_hours','0','NONPOSITIVE_HOURS'),('site','East','UNKNOWN_CATEGORY'),('orders_due','12.5','NONINTEGER_COUNT'),('units_shipped','12,34','INVALID_NUMBER'),('rework_orders','9999','SUBSET_BOUNDS')]
    for i in range(100,124):
        field,value,code=issues[(i-100)%len(issues)];bad[rows[i]['record_id']]=code;rows[i][field]=value
    conflicts={r['record_id'] for r in rows[200:206]}
    for i in range(200,206):
        changed=dict(rows[i]);changed['units_shipped']=str(int(changed['units_shipped'])+7);rows.append(changed)
    for i in range(300,312):rows.append(dict(rows[i]))
    for i in range(350,358):
        r=dict(rows[i]);r['site']=' '+r['site'].lower()+' ';rows.append(r)
    random.Random(90219).shuffle(rows)
    raw=ROOT/'data/raw_shift_feed.csv'
    with raw.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
    expected={'rows_in':554,'accepted':498,'quarantined':36,'duplicate_exact':12,'duplicate_normalized':8,'invalid_keys':sorted(bad),'conflict_keys':sorted(conflicts),'accepted_keys':sorted(r['record_id'] for r in base if r['record_id'] not in bad and r['record_id'] not in conflicts),'seed':90219,'raw_sha256':hashlib.sha256(raw.read_bytes()).hexdigest()}
    (ROOT/'data/expected.json').write_text(json.dumps(expected,indent=2))
    print('Created 554-row test feed. Expected 498 accepted, 36 quarantined, 20 duplicate rows.')
if __name__=='__main__':generate()
