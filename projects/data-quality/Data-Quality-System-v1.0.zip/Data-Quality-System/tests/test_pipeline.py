import unittest,csv,json,copy,random,tempfile,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import pipeline as p
ROOT=Path(__file__).resolve().parents[1]
class PipelineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base=p.load_csv(ROOT/'data/baseline.csv')
        cls.raw=p.load_csv(ROOT/'data/raw_shift_feed.csv')
        cls.expected=json.loads((ROOT/'data/expected.json').read_text())
    def row(self,**changes):return dict(self.base[0],**changes)
    def codes(self,row):return {code for _,code in p.normalize(row)[1]}
    def test_fixture_dispositions(self):
        result=p.process(self.raw);counts=result['report']['counts']
        self.assertEqual(counts,{'ACCEPTED':498,'QUARANTINED':36,'DUPLICATE_EXACT':12,'DUPLICATE_NORMALIZED':8})
        self.assertEqual(len(result['row_disposition']),554)
    def test_accepted_keys_match_oracle(self):
        self.assertEqual([r['record_id'] for r in p.process(self.raw)['clean']],self.expected['accepted_keys'])
    def test_accepted_values_match_original_truth(self):
        truth={r['record_id']:p.normalize(r)[0] for r in self.base}
        for r in p.process(self.raw)['clean']:self.assertEqual(r,truth[r['record_id']])
    def test_conflicts_hold_both_versions(self):
        a=self.row();b=self.row(units_shipped='999')
        r=p.process([a,b]);self.assertEqual(len(r['quarantine']),2);self.assertFalse(r['clean'])
    def test_invalid_conflict_does_not_let_valid_version_through(self):
        r=p.process([self.row(),self.row(regular_hours='')]);self.assertEqual(len(r['quarantine']),2)
    def test_raw_duplicates(self):self.assertEqual(p.process([self.row(),self.row()])['report']['counts']['DUPLICATE_EXACT'],1)
    def test_normalized_duplicates(self):self.assertEqual(p.process([self.row(),self.row(site=' north ')])['report']['counts']['DUPLICATE_NORMALIZED'],1)
    def test_row_permutation_preserves_result(self):
        a=p.process(self.raw);rr=copy.deepcopy(self.raw);random.Random(17).shuffle(rr);b=p.process(rr)
        self.assertEqual(a['clean'],b['clean']);self.assertEqual(a['report']['counts'],b['report']['counts'])
    def test_idempotence(self):
        clean=p.process(self.raw)['clean'];rerun=p.process([{k:p.text(v) for k,v in r.items()} for r in clean])
        self.assertEqual(rerun['clean'],clean);self.assertEqual(rerun['report']['counts'],{'ACCEPTED':498})
    def test_preserves_inputs(self):
        before=copy.deepcopy(self.raw);p.process(self.raw);self.assertEqual(before,self.raw)
    def test_case_and_whitespace(self):self.assertEqual(p.normalize(self.row(site=' north ',shift='am'))[0]['site'],'North')
    def test_declared_us_date(self):self.assertEqual(p.normalize(self.row(date='07/01/2025'))[0]['date'],'2025-07-01')
    def test_ambiguous_other_date_rejected(self):self.assertIn('INVALID_DATE',self.codes(self.row(date='01-07-2025')))
    def test_impossible_date(self):self.assertIn('INVALID_DATE',self.codes(self.row(date='2025-02-30')))
    def test_unknown_category(self):self.assertIn('UNKNOWN_CATEGORY',self.codes(self.row(site='Nort')))
    def test_blank_not_zero(self):self.assertIn('MISSING_VALUE',self.codes(self.row(overtime_hours='')))
    def test_zero_overtime_is_valid(self):self.assertNotIn('MISSING_VALUE',self.codes(self.row(overtime_hours='0')))
    def test_zero_regular_hours_rejected(self):self.assertIn('NONPOSITIVE_HOURS',self.codes(self.row(regular_hours='0')))
    def test_count_fraction_rejected(self):self.assertIn('NONINTEGER_COUNT',self.codes(self.row(orders_due='1.5')))
    def test_integral_decimal_count(self):self.assertEqual(p.normalize(self.row(orders_due='216.0'))[0]['orders_due'],216)
    def test_comma_grouping(self):self.assertEqual(p.normalize(self.row(units_shipped='1,234'))[0]['units_shipped'],1234)
    def test_malformed_comma_grouping(self):self.assertIn('INVALID_NUMBER',self.codes(self.row(units_shipped='12,34')))
    def test_nonfinite_rejected(self):
        for v in ['NaN','Infinity','-Infinity','1e300']:self.assertIn('INVALID_NUMBER',self.codes(self.row(regular_hours=v)))
    def test_negative_rejected(self):self.assertIn('NEGATIVE_VALUE',self.codes(self.row(on_time_orders='-1')))
    def test_order_reconciliation(self):self.assertIn('ORDER_RECONCILIATION',self.codes(self.row(on_time_orders='1')))
    def test_reason_reconciliation(self):self.assertIn('REASON_RECONCILIATION',self.codes(self.row(capacity_late='999')))
    def test_subset_reconciliation(self):self.assertIn('SUBSET_BOUNDS',self.codes(self.row(rework_orders='9999')))
    def test_month_mismatch(self):self.assertIn('MONTH_MISMATCH',self.codes(self.row(month='2025-08')))
    def test_key_dimension_mismatch(self):self.assertIn('KEY_DIMENSION_MISMATCH',self.codes(self.row(site='South')))
    def test_high_values_not_capped(self):self.assertEqual(p.normalize(self.row(units_shipped='999999'))[0]['units_shipped'],999999)
    def test_spreadsheet_formula_escape(self):self.assertEqual(p.csv_safe('=HYPERLINK("x")'),'\'=HYPERLINK("x")')
    def test_legitimate_negative_number_not_escaped(self):self.assertEqual(p.csv_safe('-1'),'-1')
    def test_bad_schema_no_partial_output(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);f=root/'bad.csv';f.write_text('date,date\n1,2\n');out=root/'out'
            with self.assertRaises(ValueError):p.run(f,out)
            self.assertFalse(out.exists())
    def test_empty_feed_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            f=Path(t)/'empty.csv';f.write_text(','.join(p.FIELDS)+'\n')
            with self.assertRaises(ValueError):p.load_csv(f)
    def test_malformed_csv_width(self):
        with tempfile.TemporaryDirectory() as t:
            f=Path(t)/'bad.csv';f.write_text(','.join(p.FIELDS)+'\n1,2\n')
            with self.assertRaises(ValueError):p.load_csv(f)
    def test_existing_output_not_overwritten(self):
        with tempfile.TemporaryDirectory() as t:
            with self.assertRaises(ValueError):p.run(ROOT/'data/raw_shift_feed.csv',Path(t))
    def test_complete_output_contract(self):
        with tempfile.TemporaryDirectory() as t:
            out=Path(t)/'run';r=p.run(ROOT/'data/raw_shift_feed.csv',out)
            self.assertEqual(len(list(out.iterdir())),7)
            self.assertEqual(len(p.load_csv(out/'clean.csv')),498)
            self.assertEqual(r['rows_in'],sum(r['counts'].values()))
if __name__=='__main__':unittest.main(verbosity=2)
