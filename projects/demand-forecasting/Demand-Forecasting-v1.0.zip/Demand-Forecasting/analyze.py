"""Reproducible synthetic demand forecasting with a chronological holdout."""
from pathlib import Path
import argparse,json,math
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
MODELS=['Seasonal naive','Recent mean','Scaled seasonal']
PRODUCTS=['Trail packs','Rain shells','Travel duffels','Training tees','Bottles','Packing cubes','Wool socks','Utility totes']
def generate():
 rng=np.random.default_rng(4192026);rows=[]
 for p,name in enumerate(PRODUCTS):
  for week in range(132):
   seasonal=1+(0.32 if p<4 else .12)*math.sin(2*math.pi*(week-p*4)/52)
   trend=1+week*(.003 if p in [0,4,5] else .0005)
   mean=(35+p*11)*seasonal*trend
   demand=max(0,round(mean+rng.normal(0,mean*.13)))
   if p==7 and rng.random()<.15:demand=0
   rows.append([str((pd.Timestamp('2023-01-02')+pd.Timedelta(weeks=week)).date()),week,name,demand])
 return pd.DataFrame(rows,columns=['week_start','week_index','product','demand_units'])
def forecast(history,model,horizon=12):
 history=np.asarray(history,dtype=float)
 if len(history)<65:raise ValueError('At least 65 weeks of training data required.')
 if not 1<=horizon<=52:raise ValueError('Horizon must be 1–52 weeks.')
 if np.any(~np.isfinite(history)) or np.any(history<0):raise ValueError('Demand must be finite and nonnegative.')
 seasonal=history[-52:-52+horizon] if horizon<52 else history[-52:]
 if model=='Seasonal naive':prediction=seasonal
 elif model=='Recent mean':prediction=np.repeat(history[-13:].mean(),horizon)
 elif model=='Scaled seasonal':
  denominator=history[-65:-52].sum()
  factor=history[-13:].sum()/denominator if denominator>0 else 1
  prediction=seasonal*factor
 else:raise ValueError('Unknown model.')
 return np.maximum(prediction,0)
def metrics(actual,prediction):
 a=np.asarray(actual,dtype=float);p=np.asarray(prediction,dtype=float);e=p-a;total=float(a.sum())
 return {'mae':float(np.abs(e).mean()),'rmse':float(np.sqrt((e**2).mean())),'wape':float(np.abs(e).sum()/total) if total else None,'bias_units':float(e.mean())}
def analyze(data):
 validation=[];holdout=[];selection=[]
 for name,g in data.groupby('product',sort=True):
  y=g.sort_values('week_index').demand_units.to_numpy()
  if len(y)!=132:raise ValueError('Expected exactly 132 weekly observations per product.')
  scores={}
  for model in MODELS:
   actual=[];predicted=[]
   for origin in [84,96,108]:
    pred=forecast(y[:origin],model);a=y[origin:origin+12]
    validation.append({'product':name,'model':model,'origin':origin,**metrics(a,pred)})
    actual.extend(a);predicted.extend(pred)
   scores[model]=metrics(actual,predicted)['mae']
  chosen=min(MODELS,key=lambda m:scores[m])
  selection.append({'product':name,'selected_model':chosen,'validation_mae':scores[chosen]})
  for model in MODELS:
   pred=forecast(y[:120],model)
   for h in range(12):holdout.append({'product':name,'week_index':120+h,'week_start':g.sort_values('week_index').iloc[120+h].week_start,'model':model,'selected':model==chosen,'actual':int(y[120+h]),'forecast':float(pred[h])})
 return pd.DataFrame(validation),pd.DataFrame(holdout),pd.DataFrame(selection)
def run(out):
 out=Path(out)
 if out.exists():raise ValueError('Use a new output directory; prior runs are preserved.')
 out.mkdir(parents=True);data=generate();v,h,s=analyze(data)
 for name,frame in [('weekly_demand',data),('validation_scores',v),('holdout_predictions',h),('model_selection',s)]:frame.to_csv(out/(name+'.csv'),index=False)
 chosen=h[h.selected];baseline=h[h.model=='Seasonal naive']
 report={'seed':4192026,'rows':len(data),'products':len(PRODUCTS),'weeks':132,'validation_origins':[84,96,108],'holdout_origin':120,'horizon':12,'selected':metrics(chosen.actual,chosen.forecast),'seasonal_baseline':metrics(baseline.actual,baseline.forecast),'selection':s.to_dict(orient='records')}
 (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
 plt.rcParams.update({'figure.facecolor':'#10130f','axes.facecolor':'#191e16','text.color':'#edf0e7','axes.labelcolor':'#edf0e7','xtick.color':'#c3cdb6','ytick.color':'#c3cdb6','axes.edgecolor':'#59654a','font.size':10})
 fig,axes=plt.subplots(2,1,figsize=(11,8),layout='constrained')
 totals=chosen.groupby('week_start')[['actual','forecast']].sum();base=baseline.groupby('week_start').forecast.sum()
 x=np.arange(12);axes[0].plot(x,totals.actual,color='#e9ece4',marker='o',label='Actual');axes[0].plot(x,totals.forecast,color='#cde78c',marker='o',label='Selected models');axes[0].plot(x,base,color='#dba28d',linestyle='--',label='Seasonal naive')
 axes[0].set_xticks(x,totals.index,rotation=35,ha='right');axes[0].set_ylabel('Demand units / week');axes[0].set_title('Twelve-week holdout: forecasts fixed before the first test week',loc='left',color='#edf0e7');axes[0].legend(facecolor='#191e16',labelcolor='#edf0e7')
 errors=chosen.groupby('product').apply(lambda g:np.mean(np.abs(g.forecast-g.actual)),include_groups=False).sort_values()
 axes[1].barh(errors.index,errors.values,color='#cde78c');axes[1].set_xlabel('Mean absolute error (units per product-week)');axes[1].set_title('Error differs by product; aggregate accuracy can hide weak segments',loc='left',color='#edf0e7')
 fig.savefig(out/'holdout-analysis.png',dpi=160);plt.close(fig)
 return report
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();print(json.dumps(run(a.output),indent=2))
