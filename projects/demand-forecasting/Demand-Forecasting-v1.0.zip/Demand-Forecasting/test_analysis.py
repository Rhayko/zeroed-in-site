import unittest
import numpy as np
from analyze import generate,forecast,metrics,analyze,MODELS
class ForecastTests(unittest.TestCase):
 def test_reproducible(self):self.assertTrue(generate().equals(generate()))
 def test_unique_complete(self):
  d=generate();self.assertEqual(len(d),1056);self.assertFalse(d.duplicated(['week_index','product']).any());self.assertTrue((d.groupby('product').size()==132).all())
 def test_nonnegative(self):self.assertTrue((generate().demand_units>=0).all())
 def test_seasonal_exact(self):np.testing.assert_equal(forecast(np.arange(120),'Seasonal naive'),np.arange(68,80))
 def test_mean_exact(self):np.testing.assert_equal(forecast(np.arange(120),'Recent mean'),np.repeat(113,12))
 def test_scaled_exact(self):np.testing.assert_allclose(forecast(np.ones(120)*10,'Scaled seasonal'),np.ones(12)*10)
 def test_zero_series(self):
  for m in MODELS:np.testing.assert_equal(forecast(np.zeros(120),m),np.zeros(12))
 def test_zero_denominator(self):self.assertIsNone(metrics([0,0],[1,1])['wape'])
 def test_metrics_known(self):
  m=metrics([10,20],[12,16]);self.assertEqual(m['mae'],3);self.assertEqual(m['wape'],.2);self.assertEqual(m['bias_units'],-1)
 def test_invalid_inputs(self):
  for y in [np.ones(10),np.repeat(-1,120),np.repeat(np.nan,120)]:
   with self.assertRaises(ValueError):forecast(y,'Recent mean')
 def test_holdout_cannot_change_selection_or_predictions(self):
  d=generate();v,h,s=analyze(d);changed=d.copy();changed.loc[changed.week_index>=120,'demand_units']=99999
  v2,h2,s2=analyze(changed);self.assertTrue(v.equals(v2));self.assertTrue(s.equals(s2));np.testing.assert_array_equal(h.forecast.to_numpy(),h2.forecast.to_numpy())
 def test_forecast_grain(self):
  _,h,s=analyze(generate());self.assertEqual(len(h[h.selected]),96);self.assertEqual(len(s),8);self.assertFalse(h.duplicated(['product','week_index','model']).any())
 def test_selection_minimum_validation_mae(self):
  v,_,s=analyze(generate())
  for r in s.itertuples():self.assertAlmostEqual(r.validation_mae,v[v["product"]==r.product].groupby('model').mae.mean().min())
if __name__=='__main__':unittest.main()
