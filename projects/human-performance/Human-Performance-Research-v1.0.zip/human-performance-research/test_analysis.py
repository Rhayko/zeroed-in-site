import tempfile
import unittest
from pathlib import Path

import pandas as pd

from analyze import analyze, build_dataset, run


class HumanPerformanceTests(unittest.TestCase):
    def test_dataset_is_reproducible(self):
        pd.testing.assert_frame_equal(build_dataset(), build_dataset())

    def test_design_has_two_sessions_per_participant(self):
        frame = build_dataset()
        self.assertEqual(len(frame), 192)
        self.assertEqual(frame.participant_id.nunique(), 96)
        self.assertTrue(frame.groupby("participant_id").size().eq(2).all())

    def test_summary_reconciles(self):
        frame = build_dataset()
        summary, report = analyze(frame)
        self.assertEqual(int(summary.sessions.sum()), len(frame))
        self.assertEqual(report["participants"], 96)
        self.assertEqual(report["sessions"], 192)

    def test_encoded_direction_is_recovered(self):
        _, report = analyze(build_dataset())
        self.assertGreater(report["paired_reaction_time_test"]["mean_restricted_minus_rested_ms"], 0)
        self.assertLess(report["sleep_reaction_correlation"]["pearson_r"], 0)
        self.assertLess(report["simple_linear_regression"]["slope_ms_per_hour"], 0)

    def test_incomplete_pair_is_rejected(self):
        frame = build_dataset().iloc[:-1]
        with self.assertRaisesRegex(ValueError, "one record"):
            analyze(frame)

    def test_outputs_are_complete(self):
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / "run"
            run(target)
            self.assertEqual(
                {p.name for p in target.iterdir()},
                {"performance_sessions.csv", "condition_summary.csv", "report.json", "sleep-reaction-analysis.png"},
            )


if __name__ == "__main__":
    unittest.main()
