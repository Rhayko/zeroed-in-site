"""Independent CSV controls and regression cases; Python standard library only."""
import csv,json,copy,math
from pathlib import Path
root=Path(__file__).resolve().parent
with (root/'data/shift_operations.csv').open() as f: raw=list(csv.DictReader(f))
numeric=list(raw[0])[5:]
rows=[dict(r,**{k:float(r[k]) for k in numeric}) for r in raw]
def validate(rr):
    assert len({r['record_id'] for r in rr})==len(rr),'Duplicate keys'
    for r in rr:
        assert r['regular_hours']>0,'Nonpositive regular hours'
        assert all(math.isfinite(r[k]) and r[k]>=0 for k in numeric),'Invalid numeric value'
        assert r['on_time_orders']+r['late_orders']==r['orders_due'],'Cohort mismatch'
        assert sum(r[k] for k in ['capacity_late','rework_late','stock_late','carrier_late','other_late'])==r['late_orders'],'Reason mismatch'
        assert r['rework_late']<=r['rework_orders']<=r['orders_due'] and r['complex_orders']<=r['orders_due'],'Invalid subset'
    return sum(r['on_time_orders'] for r in rr)/sum(r['orders_due'] for r in rr)
rate=validate(rows)
summary=json.loads((root/'data/summary.json').read_text())
assert abs(rate-summary['overall']['on_time_rate'])<1e-12
assert sum(r['orders_due'] for r in rows)==124665
assert len(rows)==528
south_pm=[r for r in rows if r['site']=='South' and r['shift']=='PM']
assert abs(validate(south_pm)-summary['groups']['South PM']['on_time_rate'])<1e-12
for case in ['duplicate','zero_hours','mismatch']:
    bad=copy.deepcopy(rows)
    if case=='duplicate':bad.append(bad[0])
    if case=='zero_hours':bad[0]['regular_hours']=0
    if case=='mismatch':bad[0]['late_orders']+=1
    try:validate(bad)
    except AssertionError:pass
    else:raise AssertionError(f'Validator failed to reject {case}')
print('Independent totals and rates match. All three corrupted-data tests rejected.')
