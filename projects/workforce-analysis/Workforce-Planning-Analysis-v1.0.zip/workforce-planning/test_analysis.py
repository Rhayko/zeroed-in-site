import tempfile
import unittest
from pathlib import Path

import pandas as pd

from analyze import analyze, build_dataset, run, wilson_interval


class WorkforceAnalysisTests(unittest.TestCase):
    def test_dataset_is_reproducible_and_unique(self):
        first = build_dataset()
        second = build_dataset()
        pd.testing.assert_frame_equal(first, second)
        self.assertEqual(len(first), 720)
        self.assertFalse(first.employee_id.duplicated().any())

    def test_missing_values_are_retained(self):
        frame = build_dataset()
        self.assertEqual(int(frame.engagement_score.isna().sum()), 29)
        summary, report = analyze(frame)
        self.assertEqual(report["missing_engagement_scores"], 29)
        self.assertEqual(int(summary.engagement_scores_present.sum()), 691)

    def test_department_counts_reconcile(self):
        frame = build_dataset()
        summary, report = analyze(frame)
        self.assertEqual(int(summary.employees.sum()), len(frame))
        self.assertEqual(int(summary.exits.sum()), report["voluntary_exits"])

    def test_wilson_interval_contains_rate(self):
        low, high = wilson_interval(72, 720)
        self.assertLess(low, 0.10)
        self.assertGreater(high, 0.10)

    def test_duplicate_employee_is_rejected(self):
        frame = build_dataset()
        frame.loc[1, "employee_id"] = frame.loc[0, "employee_id"]
        with self.assertRaisesRegex(ValueError, "unique"):
            analyze(frame)

    def test_outputs_are_complete(self):
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / "run"
            run(target)
            self.assertEqual(
                {p.name for p in target.iterdir()},
                {"workforce_records.csv", "department_summary.csv", "report.json", "turnover-by-department.png"},
            )


if __name__ == "__main__":
    unittest.main()
